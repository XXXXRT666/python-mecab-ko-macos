from mecab_ko_ import *
